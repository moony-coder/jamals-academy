# Strive SAT, Jamal's International Academy

Static site, no build step. Upload this folder to Vercel (Framework Preset: **Other**, no build command, output directory: root).

## Pages
| URL | File | What |
|---|---|---|
| `/` | `index.html` | Sends new students to `/onboarding`, returning students to `/app` |
| `/onboarding` | `onboarding.html` | 7-step setup: name, grade, test date, goal, starting score, daily goal, summary |
| `/onboarding?edit` | same | Re-run setup later without losing progress |
| `/app` | `app.html` | The whole app (dashboard, practice, bank, tests, lessons, analytics, review, plan, rewards) |

## Folder
- `assets/css` styles (`icons.css` icon font rules, `app.css`, `onboarding.css`, `fonts.css`)
- `assets/js` app code in load order (`01-core` ... `14-plus-onboarding`, `99-boot`), `config.js` = your settings
- `assets/data` question bank, lessons-era content, SAT dates
- `assets/img`, `assets/fonts` real image/font files (no more base64 inside HTML)

## Settings (`assets/js/config.js`)
`checkoutUrl` empty = no paywall, everything free. See "Plus" below.

## Data: what is real
Nothing is pre-filled. A student starts at 0 and every number comes from what they answered. Scores show "—" until 5+ answers in each section.
Progress is saved in the student's own browser (localStorage key `strive_sat_v3`). Clearing browser data, or switching phone/laptop, starts fresh.

## Plus / payments
The old version unlocked Plus for free. That is removed. To sell Plus for real you need accounts + a server that verifies payment (Stripe webhook). Until then keep `checkoutUrl` empty.

## Add questions
Edit `assets/data/questions.js` (`QB`) or `assets/data/content-bank.js` (`BANK`). Keep the same fields as existing items.
