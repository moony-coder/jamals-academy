/* ============================================================
   STATE: one real profile per browser. Starts empty; filled by /onboarding
   and by what the student actually does. Nothing is pre-filled.
   ============================================================ */
const STORE_KEY = 'strive_sat_v3';
const STATE_VERSION = 3;
const MIN_ATTEMPTS = 5;     // attempts needed in a section before we show a score estimate for it
function monday(){ const d = new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate()-todayIdx()); return ymd(d); }
function blankState(){
  return {
    v:STATE_VERSION, createdAt:Date.now(),
    profile:{ name:'', goal:null, testDate:null, onboarded:false },
    answered:0, correct:0, byTopic:{}, history:[], streak:0, testsDone:0, lastDay:null, lastTest:null, missed:[],
    studyMin:[0,0,0,0,0,0,0], weekStart:monday(), base:null, lessonDone:{}, trend:[]
  };
}
let state = blankState();
function loadState(){
  try{
    const raw = localStorage.getItem(STORE_KEY);
    if(raw){ const s = JSON.parse(raw); if(s && typeof s==='object') state = Object.assign(blankState(), s); }
  }catch(e){}
  state.profile = Object.assign(blankState().profile, state.profile||{});
  if(state.weekStart !== monday()){ state.studyMin=[0,0,0,0,0,0,0]; state.weekStart = monday(); }
  if(!state.base){ const rw=sectionScore('rw'), m=sectionScore('m'); if(rw!=null && m!=null) state.base = { rw, m }; }
}
function saveState(){ try{ localStorage.setItem(STORE_KEY, JSON.stringify(state)); }catch(e){} }
const isOnboarded = () => !!(state.profile && state.profile.onboarded);
function secAcc(sec){
  let a=0,c=0;
  for(const k in TOPICS){ if(TOPICS[k].sec===sec){ const d=state.byTopic[k]; if(d){ a+=d.attempts; c+=d.correct; } } }
  return a ? c/a : 0;
}
const accToScore = acc => Math.round((200 + 600*Math.min(1, acc*1.1))/10)*10;
function secAttempts(sec){ let a=0; for(const k in TOPICS){ if(TOPICS[k].sec===sec){ const d=state.byTopic[k]; if(d) a+=d.attempts; } } return a; }
/* null until the student has answered enough questions in that section: no invented numbers */
function sectionScore(sec){ return secAttempts(sec) >= MIN_ATTEMPTS ? accToScore(secAcc(sec)) : null; }
const estPredicted = () => { const a=sectionScore('rw'), b=sectionScore('m'); return (a==null||b==null) ? null : a+b; };
const accuracy = () => state.answered ? Math.round(state.correct/state.answered*100) : 0;
function weakest(){
  let best=null;
  for(const k in TOPICS){ const d=state.byTopic[k]; if(d && d.attempts>=5){ const a=d.correct/d.attempts; if(!best || a<best.acc) best={key:k,acc:a,attempts:d.attempts}; } }
  return best;
}
function recordAttempt(topic, isCorrect, q, chosen){
  state.answered++; if(isCorrect) state.correct++;
  const t = state.byTopic[topic] = state.byTopic[topic] || {attempts:0,correct:0};
  t.attempts++; if(isCorrect) t.correct++;
  state.history.push({topic, correct:isCorrect, ts:Date.now()});
  if(state.history.length>500) state.history.shift();
  if(isCorrect){
    state.missed = state.missed.filter(m => m.q.q !== q.q);   // answered right: leaves the review list
  } else if(q){
    if(!state.missed.some(m => m.q.q===q.q)) state.missed.unshift({q, chosen, topic, ts:Date.now()});
    if(state.missed.length>60) state.missed.pop();
  }
}
function endSession(seconds){
  const mins = Math.max(1, Math.round(seconds/60));
  state.studyMin[todayIdx()] += mins;
  const today = ymd(Date.now());
  if(state.lastDay !== today){ state.streak = (state.lastDay===ymd(Date.now()-DAY)) ? state.streak+1 : 1; state.lastDay = today; }
  const pr = estPredicted();
  if(pr!=null){
    if(!state.base) state.base = { rw:sectionScore('rw'), m:sectionScore('m') };
    state.trend.push({ts:Date.now(), score:pr}); if(state.trend.length>14) state.trend.shift();
  }
  saveState(); refreshChrome();
}

