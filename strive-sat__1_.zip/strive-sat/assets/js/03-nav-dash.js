/* ============================================================
   NAV, CHROME, INTERACTION POLISH
   ============================================================ */
const VIEWS = ['dash','practice','test','lessons','progress','review'];
let currentView = 'dash';
function go(name){
  currentView = name;
  if(name==='lessons') closeLesson(true);
  $$('.view').forEach(v => v.classList.add('hidden'));
  const v = $('#v-'+name);
  v.classList.remove('hidden'); v.style.animation='none'; void v.offsetWidth; v.style.animation='';
  $$('#nav button, #tabbar button').forEach(b => b.classList.toggle('active', b.dataset.v===name));
  placePill();
  scrollTo({top:0, behavior:'instant'});
  if(name==='dash') animateDash();
  if(name==='practice') renderPractice();
  if(name==='test') renderTestStart();
  if(name==='lessons') renderLessons();
  if(name==='progress') renderProgress();
  if(name==='review') renderReview();
  observeReveals();
}
$$('#nav button, #tabbar button').forEach(b => b.addEventListener('click', () => go(b.dataset.v)));
function placePill(){}
addEventListener('resize', placePill);

const SUPPORTS_VT = CSS.supports('animation-timeline','view()');
let revealIO = null;
function observeReveals(){
  if(SUPPORTS_VT || REDUCED) return;
  if(!revealIO) revealIO = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); revealIO.unobserve(e.target); } }), {threshold:.12});
  $$('.rv:not(.in)').forEach(el => revealIO.observe(el));
}
(function sticky(){
  const s = document.createElement('div'); s.style.cssText='position:absolute;top:0;left:0;width:1px;height:8px;pointer-events:none';
  document.body.prepend(s);
  new IntersectionObserver(e => $('#topbar').classList.toggle('stuck', !e[0].isIntersecting)).observe(s);
})();
// card spotlight + magnetic buttons (pointer events, no scroll listeners)
document.addEventListener('pointermove', e => {
  const c = e.target.closest && e.target.closest('.card');
  if(c){ const r=c.getBoundingClientRect(); c.style.setProperty('--mx',(e.clientX-r.left)+'px'); c.style.setProperty('--my',(e.clientY-r.top)+'px'); }
  if(REDUCED) return;
  const m = e.target.closest && e.target.closest('[data-mag]');
  if(m){ const r=m.getBoundingClientRect(); m.style.setProperty('--tx',((e.clientX-r.left-r.width/2)*.14)+'px'); m.style.setProperty('--ty',((e.clientY-r.top-r.height/2)*.22)+'px'); }
});
document.addEventListener('pointerout', e => { const m = e.target.closest && e.target.closest('[data-mag]'); if(m && !m.contains(e.relatedTarget)){ m.style.setProperty('--tx','0px'); m.style.setProperty('--ty','0px'); } });

/* ============================================================
   DASHBOARD
   ============================================================ */
function daysLeft(){ const d=state.profile.testDate; if(!d) return 0; return Math.max(0, Math.ceil((new Date(d+'T00:00:00') - new Date())/DAY)); }
function fmtDate(s){ return s ? new Date(s+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : '—'; }
function refreshChrome(){
  ['streakN','streakM'].forEach(id=>{ const e=$('#'+id); if(e) e.textContent = state.streak; });
  const n=$('#sideName'); if(n) n.textContent = state.profile.name || 'You';
}
function greeting(){ const h=new Date().getHours(); return h<5?'Late night':h<12?'Good morning':h<18?'Good afternoon':'Good evening'; }
function nextLesson(){ return LESSONS.find(l=>!state.lessonDone[l.id]) || null; }
function animateDash(){
  refreshChrome();
  const pr = estPredicted(), goal = state.profile.goal || 1400, d = daysLeft(), name = state.profile.name || 'there';
  $('#greet').innerHTML = esc(greeting())+', <em>Future '+(goal>=1500?'1600':String(goal))+'!</em>';
  $('#dashsub').innerHTML = pr==null
    ? 'Small steps every day lead to big results. <b>'+esc(name)+'</b>, your goal is <b>'+goal+'</b> with <b>'+d+'</b> days to go. Answer a few questions in each section and we will estimate where you stand.'
    : 'Small steps every day lead to big results. <b>'+esc(name)+'</b>, you are <b>'+Math.max(0,goal-pr)+'</b> points from <b>'+goal+'</b>, with <b>'+d+'</b> days to go.';
  $('#sGoal').textContent = goal; $('#sDate').textContent = fmtDate(state.profile.testDate).replace(/, \d{4}/,'');
  $('#sDays').textContent = d+' days left';
  const prev = state.trend.length>1 ? state.trend[state.trend.length-2].score : null;
  if(pr==null){ $('#sPred').textContent='—'; $('#sPredDelta').textContent='Needs '+MIN_ATTEMPTS+'+ answers in each section'; }
  else { countTo($('#sPred'), pr, 1600); const dl = prev==null?0:pr-prev; $('#sPredDelta').textContent = prev==null ? 'First estimate' : (dl>=0?'+':'')+dl+' since last session'; }
  // progress card (readiness ring, tests, sparkline)
  const ready = state.answered ? Math.min(100, Math.round(accuracy()*.9+10)) : 0, pc=$('#pcRing'), t0 = performance.now();
  (function tick(now){ const p = REDUCED?1:Math.min((now-t0)/1500,1), e=1-Math.pow(1-p,3), v=Math.round(e*ready); pc.style.setProperty('--v',v); $('#pcN').textContent=v+'%'; if(p<1) requestAnimationFrame(tick); })(t0);
  $('#pcTests').textContent = state.testsDone||0;
  renderSpark();
  const mins = state.studyMin.reduce((a,b)=>a+b,0);
  countTo($('#sTime'), mins/60, 1200, '', 1, '<span class="unit">hr</span>');
  countTo($('#sQs'), state.answered, 1400);
  countTo($('#sAcc'), accuracy(), 1200, '', 0, '<span class="unit">%</span>');
  const rwA = Math.round(secAcc('rw')*100), mA = Math.round(secAcc('m')*100);
  const rwS = sectionScore('rw'), mS = sectionScore('m');
  $('#rwScore').textContent = rwS==null?'—':rwS; $('#mScore').textContent = mS==null?'—':mS;
  $('#rwAcc').textContent = secAttempts('rw') ? rwA+'%' : 'No data'; $('#mAcc').textContent = secAttempts('m') ? mA+'%' : 'No data';
  const dr = (rwS!=null && state.base) ? rwS-state.base.rw : null, dm = (mS!=null && state.base) ? mS-state.base.m : null;
  $('#rwDelta').textContent = dr==null?'New':(dr>=0?'+':'')+dr; $('#mDelta').textContent = dm==null?'New':(dm>=0?'+':'')+dm;
  const nl = nextLesson(), doneN = LESSONS.filter(l=>state.lessonDone[l.id]).length;
  setTimeout(()=>{ $('#rwBar').style.width = rwS==null?'0%':(rwS-200)/6+'%'; $('#mBar').style.width = mS==null?'0%':(mS-200)/6+'%'; $('#dashBar1').style.width=Math.round(doneN/LESSONS.length*100)+'%'; },300);
  const w = weakest();
  if(w){
    $('#weakName').textContent = TOPICS[w.key].short;
    $('#weakSub').textContent = Math.round(w.acc*100)+'% accuracy, '+w.attempts+' attempts';
    setTimeout(()=>$('#weakBar').style.width = Math.round(w.acc*100)+'%',300);
    $('#planT1').textContent = 'Fix '+TOPICS[w.key].short.toLowerCase();
    $('#planP1').textContent = 'This is your weakest topic at '+Math.round(w.acc*100)+'%. One focused set is the quickest way to move your '+(TOPICS[w.key].sec==='m'?'math':'reading and writing')+' score.';
    $('#planN1').textContent = '8';
  } else {
    $('#weakName').textContent = 'Not enough data yet'; $('#weakSub').textContent = 'Answer '+MIN_ATTEMPTS+'+ questions in a topic'; $('#weakBar').style.width='0%';
    $('#planT1').textContent = 'Start with a mixed set';
    $('#planP1').textContent = 'A short mixed set across all topics shows us where you stand and what to work on first.';
    $('#planN1').textContent = '10';
  }
  if(nl){ $('#planT2').textContent = (doneN?'Next lesson: ':'Start a lesson: ')+nl.t; $('#planP2').textContent = 'A short read with a worked example, then practice on the same topic.'; $('#planN2').textContent = (nl.s.match(/(\d+) min/)||[0,'—'])[1]; }
  else { $('#planT2').textContent = 'All lessons complete'; $('#planP2').textContent = 'You have finished every lesson. Keep the skills fresh with practice sets.'; $('#planN2').textContent = '0'; }
  $('#recTitle').textContent = nl ? (doneN?'Next up: ':'Start with: ')+nl.t : 'All lessons complete';
  $('#recDesc').textContent = nl ? doneN+' of '+LESSONS.length+' lessons complete.' : 'You finished all '+LESSONS.length+' lessons.';
  $('#planN3').textContent = state.missed.length;
  $('#planP3').textContent = state.missed.length ? 'Missed questions stay here until you answer them correctly. That is where most of the learning happens.' : 'Nothing to re-try yet. Missed questions will queue up here.';
  renderWeekly('#weeklyDash', state.studyMin);
  $('#weekTag').textContent = mins+' min';
}
function renderSpark(){
  if(!state.trend.length){ $('#pcSpark').innerHTML='<div class="muted" style="font-size:12.5px;padding-top:10px">Your score trend appears after your first scored session.</div>'; return; }
  const pts=state.trend.slice(-10).map(p=>p.score), W=300,H=70,lo=Math.min(...pts)-20,hi=Math.max(...pts)+20;
  const X=i=>pts.length>1?i/(pts.length-1)*W:W/2, Y=v=>4+(1-(v-lo)/(hi-lo))*(H-8);
  let d=''; pts.forEach((v,i)=>{ d+=(i?'L':'M')+X(i).toFixed(1)+' '+Y(v).toFixed(1); });
  $('#pcSpark').innerHTML='<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" aria-label="Score trend"><defs><linearGradient id="spg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#22c55e" stop-opacity=".28"/><stop offset="1" stop-color="#22c55e" stop-opacity="0"/></linearGradient></defs><path class="sa" d="'+d+' L'+W+' '+H+' L0 '+H+' Z"/><path class="sl" id="slLine" d="'+d+'"/></svg>';
  const ln=$('#slLine'), len=Math.ceil(ln.getTotalLength?ln.getTotalLength():600); ln.style.setProperty('--len',len);
  const card=$('#progCard'); card.classList.remove('on'); void card.offsetWidth; setTimeout(()=>card.classList.add('on'),150);
}
function hydrate(root=document){
  root.querySelectorAll('[data-img]').forEach(el=>{ el.src=IMG[el.dataset.img]; });
  root.querySelectorAll('[data-bg]').forEach(el=>{ el.style.backgroundImage='url('+IMG[el.dataset.bg]+')'; });
}
function renderWeekly(sel, data){
  const w = $(sel); if(!w) return; w.innerHTML='';
  const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], max=Math.max(...data,1), ti=todayIdx();
  data.forEach((v,i)=>{
    const d=document.createElement('div'); d.className='day';
    d.innerHTML='<div class="bwrap"><div class="b'+(i===ti?' today':'')+'" style="height:0" title="'+v+' min"></div></div><div class="lbl">'+days[i]+'</div><div class="v">'+v+'m</div>';
    w.appendChild(d);
    setTimeout(()=>{ d.querySelector('.b').style.height=Math.max(v/max*100, v?4:1)+'%'; }, 70*i+120);
  });
}
function drillWeak(){ const w=weakest(); startPractice(w?w.key:'mixed'); }

/* ============================================================
   PRACTICE PICKER
   ============================================================ */
function renderPractice(){
  const g = $('#pickGrid'); g.innerHTML='';
  const cards = Object.entries(TOPICS).map(([k,t])=>({k,icon:t.icon,title:t.short,desc:t.desc,tag:t.sec==='m'?'Math':'R&W',n:Math.min(t.n,BANK[k].length),min:t.min}));
  cards.push({k:'mixed',icon:'ph-lightning',title:'Mixed set',desc:'All topics in one adaptive run. Best for daily practice.',tag:'Adaptive',n:10,min:15});
  cards.forEach((c,i)=>{
    const d=document.createElement('div'); d.className='card pick lift click rv'; d.style.setProperty('--d',i%3);
    d.innerHTML='<div class="row" style="justify-content:space-between"><span class="ic"><i class="ph '+c.icon+'"></i></span><span class="tag '+(c.k==='mixed'?'warn':'acc')+'">'+c.tag+'</span></div><h3>'+esc(c.title)+'</h3><p>'+esc(c.desc)+'</p><div class="row" style="gap:8px;margin-top:2px"><span class="tag mono">'+c.n+' Q</span><span class="tag mono">~'+c.min+' min</span><i class="ph ph-arrow-right go"></i></div>';
    d.onclick=()=>startPractice(c.k); g.appendChild(d);
  });
  const f=$('#focusGrid'); f.innerHTML='';
  const ranked = Object.keys(TOPICS).map(k=>{const d=state.byTopic[k]||{attempts:0,correct:0}; return {k,acc:d.attempts?d.correct/d.attempts:null,at:d.attempts};}).filter(x=>x.acc!==null).sort((a,b)=>a.acc-b.acc).slice(0,2);
  ranked.forEach((x,i)=>{
    const d=document.createElement('div'); d.className='card rv'; d.style.setProperty('--d',i);
    d.innerHTML='<div class="row" style="justify-content:space-between;gap:16px"><div><span class="tag '+(i===0?'bad':'warn')+'">'+(i===0?'Weakest topic':'Needs work')+'</span><h3 style="margin-top:12px;font-size:17px;letter-spacing:-.01em">'+esc(TOPICS[x.k].short)+', '+Math.round(x.acc*100)+'% accuracy</h3></div><button class="btn" data-mag>Drill it<i class="ph ph-arrow-right"></i></button></div>';
    d.querySelector('button').onclick=()=>startPractice(x.k); f.appendChild(d);
  });
}
function renderTestStart(){
  const rwN = (BANK.rw_craft.length+BANK.rw_info.length+BANK.rw_conv.length), mN = BANK.math_algebra.length+BANK.math_adv.length;
  const rwPer = Math.floor(rwN/2), mPer = Math.floor(mN/2);
  const rwMin = Math.ceil(rwPer*71/60), mMin = Math.ceil(mPer*95/60);
  $('#tRWh').textContent = '2 modules, '+(rwPer*2)+' questions, '+(rwMin*2)+' min';
  $('#tMh').textContent = '2 modules, '+(mPer*2)+' questions, '+(mMin*2)+' min';
  const tot = (rwMin+mMin)*2;
  $('#tTotal').textContent = 'Total time: about '+Math.floor(tot/60)+' hr '+(tot%60)+' min';
  const w = $('#lastTestWrap'); w.innerHTML='';
  if(state.lastTest){
    const t=state.lastTest;
    w.innerHTML='<div class="card rv" style="margin-top:18px"><div class="row" style="justify-content:space-between"><div><span class="tag good">Last test</span><div style="font-size:34px;font-weight:600;letter-spacing:-.03em;margin-top:12px">'+t.score+'</div><div class="muted" style="font-size:13px;margin-top:4px">R&amp;W '+t.rw+', Math '+t.m+', '+t.correct+' of '+t.total+' correct on '+new Date(t.ts).toLocaleDateString('en-US',{month:'short',day:'numeric'})+'</div></div><button class="btn" onclick="go(\'review\')">Review answers<i class="ph ph-arrow-right"></i></button></div></div>';
  }
}

