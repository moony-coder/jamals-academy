/* ===== v8: onboarding checklist, Plus paywall, capped popups ===== */
(function(){
 /* ---- config: edit prices and limits here ---- */
 const CFG=window.STRIVE_CONFIG||{};
 const PLUS={name:'Strive Plus',cur:CFG.currency||'$',month:CFG.priceMonth||12,year:CFG.priceYear||79,freeBankPerDay:CFG.freeBankPerDay||20,
  checkoutUrl:CFG.checkoutUrl||''};
 /* Paywall is OFF until you set checkoutUrl in assets/js/config.js. While off, everything is unlocked. */
 const PAYWALL_ON=!!PLUS.checkoutUrl;
 const DAYMS=86400000, today=()=>ymd(Date.now());
 const isPlus=()=>!PAYWALL_ON||!!state.plus;
 window.isPlus=isPlus;
 const pct=()=>Math.round((1-PLUS.year/(PLUS.month*12))*100);
 const money=n=>PLUS.cur+(Math.round(n*100)/100).toString().replace(/\.(\d)$/,'.$10');

 /* ---- measurement: counters + a DOM event you can forward to analytics ---- */
 function track(ev,p){const e=E(),a=e.an=e.an||{},k=ev+(p?':'+p:'');a[k]=(a[k]||0)+1;saveState();
  try{dispatchEvent(new CustomEvent('strive:track',{detail:{ev:ev,p:p||null}}));}catch(_){}}
 window.trackEvent=track;

 /* ---- free-tier usage: question bank per day ---- */
 const bk=()=>{const e=E();if(!e.bk||e.bk.d!==today())e.bk={d:today(),n:0};return e.bk;};
 const bankLeft=()=>Math.max(0,PLUS.freeBankPerDay-bk().n);
 const _ra=recordAttempt;
 recordAttempt=function(tp,ok,q,ch){_ra(tp,ok,q,ch);if(X&&X.topic==='bank'&&!isPlus()){bk().n++;saveState();}};
 const _sl=startList;
 startList=function(items,o){
  o=o||{};
  if(!isPlus()){
   if(o.timed){openPaywall('timed',{after:()=>_sl(items,o)});return;}
   const left=bankLeft();
   if(left<=0){openPaywall('limit');return;}
   if(items.length>left){items=items.slice(0,left);toast('Your last '+left+' free question'+(left===1?'':'s')+' for today','ph-lock-simple');}
  }
  _sl(items,o);
 };

 /* ---- paywall ---- */
 const COPY={
  timed:{ico:'ph-timer',h:'Train against the clock',s:'Timed drills give you real test pacing: ten questions from your weakest skills with a running timer.',cta:'Unlock timed drills'},
  limit:{ico:'ph-lock-simple',h:'You used all '+PLUS.freeBankPerDay+' free questions today',s:'They reset at midnight. Plus removes the daily cap so a long study day never stalls your streak.',cta:'Get unlimited practice'},
  soft:{ico:'ph-sparkle',h:'Practice without a daily cap',s:'Plus adds timed drills and unlimited question bank practice.',cta:'Get Plus'}
 };
 let pwOpen=null;
 function closePw(m,prev){document.removeEventListener('keydown',m._k,true);m.remove();pwOpen=null;if(prev&&prev.focus)try{prev.focus({preventScroll:true});}catch(_){}}
 function openPaywall(kind,o){
  o=o||{};if(pwOpen)return;
  const prev=document.activeElement;
  track('paywall_view',kind);
  if(isPlus()){return openManage();}
  const c=COPY[kind]||COPY.soft;let plan='year';
  const demo=kind==='timed'?'<div class="pw-demo"><div><div class="tm">10:00</div><small>10 questions, one running clock</small></div><div class="pw-dots" aria-hidden="true">'+'<i class="on"></i>'.repeat(4)+'<i></i>'.repeat(6)+'</div></div>'
   :kind==='limit'?'<div class="pw-use"><div class="row"><span>Free questions today</span><b>'+PLUS.freeBankPerDay+' of '+PLUS.freeBankPerDay+'</b></div><div class="bar"><i style="width:100%"></i></div></div>':'';
  const row=(a,f,p)=>'<div class="r">'+a+'</div><div class="r c">'+f+'</div><div class="r c plus">'+p+'</div>';
  const m=openModal(
   '<div class="pw-top"><span class="pw-ico"><i class="ph '+c.ico+'"></i></span><h2 id="pwH">'+c.h+'</h2></div>'+
   '<p class="pw-sub">'+c.s+'</p>'+demo+
   '<div class="pw-cmp"><div class="hd">&nbsp;</div><div class="hd">Free</div><div class="hd">Plus</div>'+
    row('Question bank per day',String(PLUS.freeBankPerDay),'<i class="ph ph-infinity"></i>')+
    row('Timed drills','<i class="ph ph-lock-simple"></i>','<i class="ph ph-check"></i>')+
    row('Lessons, practice sets, study plan','<i class="ph ph-check"></i>','<i class="ph ph-check"></i>')+'</div>'+
   '<div class="pw-plans" role="radiogroup" aria-label="Plan">'+
    '<button type="button" class="pw-plan" role="radio" data-p="year" aria-checked="true"><em>Save '+pct()+'%</em><b>Yearly</b><span>'+money(PLUS.year)+'/yr ('+money(PLUS.year/12)+'/mo)</span></button>'+
    '<button type="button" class="pw-plan" role="radio" data-p="month" aria-checked="false"><b>Monthly</b><span>'+money(PLUS.month)+'/mo</span></button></div>'+
   '<div class="pw-cta"><button type="button" class="btn acc" id="pwGo">'+c.cta+'<i class="ph ph-arrow-right"></i></button><button type="button" class="pw-no" id="pwNo">Not now</button></div>');
  m.classList.add('pwbg');const box=m.querySelector('.modal');box.classList.add('pw');box.setAttribute('aria-labelledby','pwH');pwOpen=m;
  const dismiss=why=>{track('paywall_dismiss',kind+':'+why);closePw(m,prev);};
  m._k=e=>{
   if(e.key==='Escape'){e.stopPropagation();dismiss('esc');}
   if(e.key==='Tab'){const f=[...box.querySelectorAll('button')];if(!f.length)return;const i=f.indexOf(document.activeElement);
    if(e.shiftKey&&i<=0){e.preventDefault();f[f.length-1].focus();}else if(!e.shiftKey&&i===f.length-1){e.preventDefault();f[0].focus();}}
  };
  document.addEventListener('keydown',m._k,true);
  m.addEventListener('pointerdown',e=>{if(e.target===m)dismiss('outside');},true);
  box.querySelectorAll('.pw-plan').forEach(b=>b.onclick=()=>{plan=b.dataset.p;box.querySelectorAll('.pw-plan').forEach(x=>x.setAttribute('aria-checked',x===b));});
  box.querySelector('#pwNo').onclick=()=>dismiss('no');
  box.querySelector('#pwGo').onclick=()=>{
   track('paywall_cta',kind+':'+plan);
   checkout(plan,()=>{showWin(box,kind,o,()=>closePw(m,prev));});
  };
  setTimeout(()=>{const g=box.querySelector('#pwGo');if(g)g.focus({preventScroll:true});},60);
  return m;
 }
 window.openPaywall=openPaywall;
 function checkout(plan,done){
  /* No local unlock: Plus can only be granted by a real, verified payment (needs a backend, see README). */
  window.open(PLUS.checkoutUrl+(PLUS.checkoutUrl.indexOf('?')>-1?'&':'?')+'plan='+plan,'_blank','noopener');
 }
 function showWin(box,kind,o,close){
  box.innerHTML='<div class="pw-win"><span class="pw-ico"><i class="ph ph-check"></i></span><h2>Plus is on</h2><p class="pw-sub" style="margin-top:8px">Here is what just opened up.</p><ul><li><i class="ph ph-timer"></i>Timed drills in the question bank</li><li><i class="ph ph-infinity"></i>No daily question limit</li></ul><div class="pw-cta"><button type="button" class="btn acc" id="pwKeep">'+(o.after?'Start my timed drill':'Keep practicing')+'<i class="ph ph-arrow-right"></i></button></div></div>';
  const b=box.querySelector('#pwKeep');b.focus({preventScroll:true});
  b.onclick=()=>{close();if(o.after)setTimeout(o.after,150);};
 }
 function openManage(){
  const p=state.plus,prev=document.activeElement;
  const m=openModal('<div class="pw-top"><span class="pw-ico"><i class="ph ph-crown-simple"></i></span><h2 id="pwH">You are on Plus</h2></div><p class="pw-sub">Plan: '+(p.plan==='year'?'Yearly':'Monthly')+'. Timed drills and unlimited question bank practice are on.</p><div class="pw-cta"><button type="button" class="btn acc" id="pwOk">Back to practice</button><button type="button" class="pw-no" id="pwDown">Switch to the free plan</button></div>');
  const box=m.querySelector('.modal');box.classList.add('pw');box.setAttribute('aria-labelledby','pwH');pwOpen=m;
  m._k=e=>{if(e.key==='Escape'){e.stopPropagation();closePw(m,prev);}};document.addEventListener('keydown',m._k,true);
  box.querySelector('#pwOk').onclick=()=>closePw(m,prev);
  box.querySelector('#pwDown').onclick=()=>{delete state.plus;saveState();track('downgrade');paintPlan();paintGates();closePw(m,prev);toast('You are on the free plan','ph-info');};
  box.querySelector('#pwOk').focus({preventScroll:true});
 }

 /* ---- plan chip + locked controls ---- */
 function paintPlan(){
  const c=$('#planChip'),cm=$('#planChipM');
  if(c)c.hidden=!PAYWALL_ON;
  if(c&&PAYWALL_ON){c.classList.toggle('on',isPlus());c.innerHTML=isPlus()?'<span><i class="ph-fill ph-crown-simple"></i>Plus</span><em>Manage</em>':'<span><i class="ph ph-crown-simple"></i>Free plan</span><em>Upgrade</em>';}
  if(cm)cm.hidden=isPlus()||!PAYWALL_ON;
 }
 function paintGates(){
  const t=$('#bkTimed');
  if(t){t.classList.toggle('lockedbtn',!isPlus());t.innerHTML=(isPlus()?'<i class="ph ph-timer"></i>':'<i class="ph ph-lock-simple"></i>')+'Timed drill (10)';}
  const q=$('#bkQuota');
  if(q)q.innerHTML=isPlus()?'':'<b>'+bankLeft()+'</b> of '+PLUS.freeBankPerDay+' free today';
 }
 const _rb=renderBank;renderBank=function(){_rb();paintGates();};
 document.addEventListener('click',e=>{if(e.target.closest('#planChip,#planChipM')){track('plan_chip');openPaywall('soft');}});

 /* ---- onboarding checklist (dashboard) ---- */
 const ob=()=>{const e=E();e.ob=e.ob||{v:{}};return e.ob;};
 const OB=[
  {k:'goal',t:'Set your goal and test date',d:'Done. Your countdown and plan use it.',done:()=>true,go:()=>openSettings()},
  {k:'diag',t:'Take the diagnostic',d:()=>'A short set across '+Object.keys(TOPICS).length+' topics that finds your weakest skills.',done:()=>!!E().diag,go:()=>startDiagnostic()},
  {k:'bank',t:'Solve 5 bank questions',d:()=>Math.min(5,Object.keys(E().seen).length)+' of 5 solved so far.',done:()=>Object.keys(E().seen).length>=5,go:()=>go('bank')},
  {k:'plan',t:'Open your study plan',d:'It is built from your diagnostic.',done:()=>!!ob().v.plan,go:()=>go('plan')},
  {k:'day',t:'Reach your daily goal once',d:()=>todayN()+' of '+E().goal+' questions today.',done:()=>!!ob().day||todayN()>=E().goal,go:()=>startPractice('mixed')}
 ];
 const ds=d=>typeof d==='function'?d():d;
 function renderOnb(){
  const host=$('#onb');if(!host)return;
  const o=ob();
  if(!o.day&&todayN()>=E().goal){o.day=1;}
  if(o.dismissed){host.innerHTML='';return;}
  const done=OB.filter(i=>i.done()).length,all=done===OB.length,nextK=(OB.find(i=>!i.done())||{}).k;
  if(all&&!o.fin){o.fin=Date.now();saveState();track('onboarding_complete');
   setTimeout(()=>{try{burst();}catch(_){}toast('Setup complete. Nice work.','ph-confetti');},400);}
  host.innerHTML='<div class="card onb" style="margin-top:22px"><div class="onb-h"><b>'+(all?'You are all set':'Get set up')+'</b><span class="tag acc">'+done+' of '+OB.length+'</span><button type="button" class="onb-x" id="onbX" aria-label="Hide checklist"><i class="ph ph-x"></i></button></div>'+
   '<div class="onb-bar" role="progressbar" aria-valuemin="0" aria-valuemax="'+OB.length+'" aria-valuenow="'+done+'"><i style="transform:scaleX('+(done/OB.length)+')"></i></div>'+
   (all?'<div class="onb-fin"><span>Everything here is done. You can keep going from the practice tab.</span><button type="button" class="btn line sm" id="onbDone">Hide</button></div>':
   '<div class="onb-list">'+OB.map(i=>{const d=i.done();return (d?'<div class="onb-row done">':'<button type="button" class="onb-row'+(i.k===nextK?' next':'')+'" data-k="'+i.k+'">')+
     '<span class="ck"><i class="ph ph-check"></i></span><span><b>'+i.t+'</b><small>'+ds(i.d)+'</small></span><i class="ph ph-arrow-right go"></i>'+(d?'</div>':'</button>');}).join('')+'</div>')+'</div>';
  const x=$('#onbX');if(x)x.onclick=()=>{o.dismissed=Date.now();saveState();track('onboarding_hide');renderOnb();};
  const dn=$('#onbDone');if(dn)dn.onclick=()=>{o.dismissed=Date.now();saveState();renderOnb();};
  host.querySelectorAll('button.onb-row').forEach(b=>b.onclick=()=>{track('onboarding_step',b.dataset.k);OB.find(i=>i.k===b.dataset.k).go();});
  saveState();
 }
 const _go=go;go=function(n){if(n==='plan'){ob().v.plan=1;}_go(n);if(n==='dash')renderOnb();};

 /* ---- registration banner (dashboard) ---- */
 function renderAnn(){
  const v=$('#v-dash');if(!v)return;let a=$('#annbar');
  const e=E(),p=e.pop=e.pop||{},now=Date.now(),t=today(),ent=SAT_DATES.find(d=>d.d===state.profile.testDate);
  let msg='',days=0;
  if(ent&&!ent.est){
   if(t<=ent.r){days=Math.ceil((new Date(ent.r+'T23:59:59')-now)/DAYMS);if(days<=21)msg='Registration for '+satLong(ent.d)+' closes '+satShort(ent.r)+' ('+days+' day'+(days===1?'':'s')+' left).';}
   else if(t<=ent.l){msg='Late registration for '+satLong(ent.d)+' ends '+satShort(ent.l)+'.';}
  }
  if(!msg||(p.annAt&&now-p.annAt<7*DAYMS)){if(a)a.remove();return;}
  if(!a){a=document.createElement('div');a.id='annbar';a.className='annbar';a.setAttribute('role','region');a.setAttribute('aria-label','Registration reminder');v.insertBefore(a,v.firstChild);track('banner_view','reg');}
  a.innerHTML='<i class="ph ph-calendar-check"></i><span>'+msg+'</span><a href="https://satsuite.collegeboard.org/sat/registration" target="_blank" rel="noopener">Register</a><button type="button" aria-label="Dismiss reminder"><i class="ph ph-x"></i></button>';
  a.querySelector('button').onclick=()=>{p.annAt=Date.now();saveState();track('banner_dismiss','reg');a.remove();};
  a.querySelector('a').onclick=()=>track('banner_click','reg');
 }

 /* ---- popup manager: one popup per session, never in an exam, 14-day cooldown after a no ---- */
 const POP={shown:0};
 function popOK(){const ex=$('#exam');return document.body.classList.contains('done')&&!document.hidden&&!pwOpen&&!$('#mw')&&!$('.modal-bg')&&!$('#mn')&&!$('.popin')&&!(ex&&!ex.classList.contains('hidden'))&&POP.shown<1&&currentView==='dash';}
 function slideIn(id,h,txt,cta,fn,no){
  const d=document.createElement('div');d.className='popin';d.id=id;d.setAttribute('role','dialog');d.setAttribute('aria-label',h);
  d.innerHTML='<button type="button" class="x" aria-label="Close"><i class="ph ph-x"></i></button><h4>'+h+'</h4><p>'+txt+'</p><div class="acts"><button type="button" class="btn acc sm" id="piGo">'+cta+'</button><button type="button" class="btn ghost sm" id="piNo">Not now</button></div>';
  document.body.appendChild(d);POP.shown++;
  const kill=why=>{d.classList.remove('in');setTimeout(()=>d.remove(),500);document.removeEventListener('keydown',key,true);no&&no(why);};
  const key=e=>{if(e.key==='Escape')kill('esc');};document.addEventListener('keydown',key,true);
  d.querySelector('.x').onclick=()=>kill('x');d.querySelector('#piNo').onclick=()=>kill('no');
  d.querySelector('#piGo').onclick=()=>{d.classList.remove('in');setTimeout(()=>d.remove(),500);document.removeEventListener('keydown',key,true);fn();};
  requestAnimationFrame(()=>requestAnimationFrame(()=>d.classList.add('in')));
 }
 function maybeUpgradePop(){
  const e=E(),p=e.pop=e.pop||{};
  if(isPlus()||!popOK())return;
  if((e.fin||0)<3||(p.upAt&&Date.now()-p.upAt<14*DAYMS))return;
  track('pop_view','upgrade');
  slideIn('popUp','Ready for timed practice?','You have finished '+e.fin+' sessions. Plus adds timed drills and removes the daily limit.','See Plus',
   ()=>{track('pop_click','upgrade');openPaywall('soft');},
   why=>{p.upAt=Date.now();saveState();track('pop_dismiss','upgrade:'+why);});
 }
 /* count finished sessions: this is the "value delivered" signal for the soft upsell */
 const _fp=finishPractice;
 finishPractice=function(){_fp();const e=E();e.fin=(e.fin||0)+1;saveState();};

 /* ---- wire into the dashboard ---- */
 const _ad=animateDash;
 animateDash=function(){_ad();renderOnb();renderAnn();paintPlan();setTimeout(maybeUpgradePop,6000);};
 paintPlan();
 window.__v8={PLUS:PLUS,renderOnb:renderOnb,renderAnn:renderAnn,maybeUpgradePop:maybeUpgradePop,bankLeft:bankLeft};
})();

