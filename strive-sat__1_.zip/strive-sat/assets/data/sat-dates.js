/* Official College Board SAT dates (all Saturdays). 2027-28 dates are anticipated. */
const SAT_DATES=[
 {d:'2026-08-22',r:'2026-08-07',l:'2026-08-11'},{d:'2026-09-12',r:'2026-08-28',l:'2026-09-01'},
 {d:'2026-10-03',r:'2026-09-18',l:'2026-09-22'},{d:'2026-11-07',r:'2026-10-23',l:'2026-10-27'},
 {d:'2026-12-05',r:'2026-11-20',l:'2026-11-24'},{d:'2027-03-06',r:'2027-02-19',l:'2027-02-23'},
 {d:'2027-05-01',r:'2027-04-16',l:'2027-04-20'},{d:'2027-06-05',r:'2027-05-21',l:'2027-05-25'},
 {d:'2027-08-28',est:1},{d:'2027-09-18',est:1},{d:'2027-10-02',est:1},{d:'2027-11-06',est:1},{d:'2027-12-04',est:1}];
const satAt=s=>new Date(s+'T08:00:00');
const satLong=s=>new Date(s+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
const satShort=s=>new Date(s+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric'});
function satUpcoming(){const t=ymd(Date.now());return SAT_DATES.filter(d=>d.d>=t);}
