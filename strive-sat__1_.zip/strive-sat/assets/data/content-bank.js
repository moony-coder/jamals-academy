(function(){const p=state.profile,up=satUpcoming();
 if(up.length&&p.testDate&&!up.some(d=>d.d===p.testDate)){const t=new Date(p.testDate+'T00:00:00').getTime();
  p.testDate=up.reduce((a,b)=>Math.abs(new Date(b.d+'T00:00:00')-t)<Math.abs(new Date(a.d+'T00:00:00')-t)?b:a).d;saveState();}})();
const BANK = {
  math_algebra: [
    { q:"If 3x + 7 = 22, what is the value of x?", opts:["3","5","7","15"], a:1, diff:"Easy",
      why:"Subtract 7 from both sides: 3x = 15. Divide by 3: x = 5." },
    { q:"The sum of two numbers is 30 and their difference is 6. What is the larger number?", opts:["12","15","18","21"], a:2, diff:"Easy",
      why:"Let the numbers be x and y. x+y=30, x−y=6. Adding: 2x=36, so x=18." },
    { q:"A line passes through (2, 3) and (6, 11). What is its slope?", opts:["1","2","3","4"], a:1, diff:"Easy",
      why:"Slope = (11−3)/(6−2) = 8/4 = 2." },
    { q:"If f(x) = 2x² − 3x + 1, what is f(2)?", opts:["1","3","5","7"], a:1, diff:"Medium",
      why:"f(2) = 2(4) − 3(2) + 1 = 8 − 6 + 1 = 3." },
    { q:"Which value of x satisfies |x − 4| = 7?", opts:["−3 or 11","3 or 11","−11 or 3","−3 or −11"], a:0, diff:"Medium",
      why:"|x−4|=7 means x−4=7 or x−4=−7. So x=11 or x=−3." },
    { q:"A shirt costs $40 after a 20% discount. What was the original price?", opts:["$48","$50","$52","$60"], a:1, diff:"Medium",
      why:"If the discounted price is 80% of the original: 0.8x=40, so x=$50." },
    { q:"If 2(x − 3) = 4x + 8, what is x?", opts:["−7","−4","4","7"], a:0, diff:"Medium",
      why:"2x−6 = 4x+8 → −14 = 2x → x = −7." },
    { q:"The average of 5 numbers is 12. If four of them are 8, 10, 14, and 15, what is the fifth?", opts:["11","12","13","14"], a:2, diff:"Medium",
      why:"Sum of all 5 = 60. Sum of four = 47. Fifth = 60 − 47 = 13." },
    { q:"A car travels 240 miles in 4 hours. At the same rate, how far will it travel in 7 hours?", opts:["360 mi","400 mi","420 mi","480 mi"], a:2, diff:"Easy",
      why:"Rate = 240/4 = 60 mph. In 7 hours: 60 × 7 = 420 miles." },
    { q:"If 5x − 3y = 12 and x = 3, what is y?", opts:["1","2","3","4"], a:0, diff:"Easy",
      why:"5(3) − 3y = 12 → 15 − 3y = 12 → 3y = 3 → y = 1." }
  ],
  math_adv: [
    { q:"The function f(x) = x² − 4x + 7 has its vertex at which point?", opts:["(2, 3)","(−2, 3)","(2, 7)","(4, 7)"], a:0, diff:"Medium",
      why:"Vertex x = −b/(2a) = 4/2 = 2. f(2) = 4 − 8 + 7 = 3. Vertex: (2, 3)." },
    { q:"If 2^(x+1) = 32, what is x?", opts:["3","4","5","6"], a:1, diff:"Medium",
      why:"32 = 2^5, so x+1 = 5, x = 4." },
    { q:"A right triangle has legs of length 6 and 8. What is the length of the hypotenuse?", opts:["10","12","14","√48"], a:0, diff:"Easy",
      why:"By the Pythagorean theorem: √(36+64) = √100 = 10." },
    { q:"The expression (x+3)(x−5) is equivalent to:", opts:["x²−2x−15","x²+2x−15","x²−8x+15","x²−15"], a:0, diff:"Easy",
      why:"FOIL: x² − 5x + 3x − 15 = x² − 2x − 15." },
    { q:"If a circle has a radius of 5, what is its area?", opts:["10π","20π","25π","50π"], a:2, diff:"Easy",
      why:"Area = πr² = π(5²) = 25π." },
    { q:"The population of a town doubles every 10 years. If it is 8,000 now, what will it be in 30 years?", opts:["24,000","32,000","48,000","64,000"], a:3, diff:"Medium",
      why:"30 years = 3 doublings. 8,000 × 2³ = 8,000 × 8 = 64,000." },
    { q:"If (x−2)/(x+3) = 4, what is x?", opts:["−14/3","−10/3","10/3","14/3"], a:0, diff:"Hard",
      why:"x−2 = 4(x+3) = 4x+12 → −14 = 3x → x = −14/3." },
    { q:"What is the sum of the solutions to x² − 5x + 6 = 0?", opts:["−5","5","6","−6"], a:1, diff:"Easy",
      why:"By Vieta's formulas, sum = −b/a = 5." },
    { q:"If sin(θ) = 0.6 in a right triangle, and the hypotenuse is 10, what is the opposite side?", opts:["4","5","6","8"], a:2, diff:"Medium",
      why:"sin(θ) = opposite/hypotenuse → 0.6 = opposite/10 → opposite = 6." },
    { q:"The graph of y = (x−1)² + 3 is shifted how from y = x²?", opts:["Right 1, up 3","Left 1, up 3","Right 3, up 1","Left 3, up 1"], a:0, diff:"Medium",
      why:"(x−h)² + k shifts right h and up k. Here h=1, k=3." }
  ],
  rw_craft: [
    { passage:"The scientist's findings were so _____ that they overturned decades of accepted theory. Colleagues who had once dismissed her work now cited it as foundational.",
      q:"Which choice completes the text with the most logical and precise word?", opts:["mundane","revolutionary","tentative","conventional"], a:1, diff:"Easy",
      why:"'Overturned decades of accepted theory' signals something groundbreaking, 'revolutionary' fits. 'Mundane' and 'conventional' contradict the sentence." },
    { passage:"In her 1920s writings, the author repeatedly returned to the factory floor. These descriptions were not merely decorative; they anchored her arguments about labor reform in vivid, tangible detail.",
      q:"The author mentions the 1920s primarily to:", opts:["argue that the decade was misunderstood","provide historical context for a trend","criticize a specific policy","introduce a counterargument"], a:1, diff:"Medium",
      why:"The reference functions as background context that sets up the main claim, a classic 'function of a detail' question." },
    { passage:"Urban gardens occupy a curious position in city planning. They cool neighborhoods, absorb stormwater, and provide fresh produce. But they also create community, neighbors who once passed silently now stop to talk across a shared plot.",
      q:"Which choice best states the main idea of the passage?", opts:["Urban gardens reduce city temperatures","Urban gardens have environmental and social benefits","Cities should ban rooftop gardens","Gardening is a popular hobby"], a:1, diff:"Easy",
      why:"The passage surveys multiple benefits, environmental and social, making B the best main-idea summary." },
    { passage:"The evidence was compelling: three independent studies, from three different countries, using three different methods, arrived at the same conclusion.",
      q:"The word 'compelling' in the sentence most nearly means:", opts:["forced","persuasive","optional","confusing"], a:1, diff:"Easy",
      why:"In context, the author describes evidence that convinces, 'persuasive' is the closest match." },
    { passage:"The project began with such promise. Volunteers cleared the lot. Plans were drawn. But then the funding dried up, and the lot reverted to weeds.",
      q:"The author's tone in the passage can best be described as:", opts:["skeptical","optimistic","disappointed","angry"], a:2, diff:"Medium",
      why:"The contrast between initial promise and reversion to weeds supports a disappointed tone." },
    { passage:"The committee's report was praised for its clarity. It avoided jargon, defined its terms, and provided concrete examples for every claim.",
      q:"Which choice best describes the function of the second sentence?", opts:["It contradicts the first sentence","It provides evidence for the first sentence","It introduces a new topic","It qualifies the first sentence"], a:1, diff:"Medium",
      why:"The second sentence lists specific reasons the report was praised, supporting evidence for the claim in sentence 1." },
    { passage:"Unlike her contemporaries, who favored ornate prose, the novelist wrote in a spare, almost severe style. Each sentence carried weight precisely because nothing was wasted.",
      q:"The passage primarily serves to:", opts:["criticize ornate prose","describe the novelist's distinctive style","summarize the novelist's biography","compare two literary movements"], a:1, diff:"Easy",
      why:"The passage focuses on describing what made the novelist's style distinctive." },
    { passage:"The proposal was ambitious. It was also expensive. Whether the city could afford it remained an open question.",
      q:"The author's attitude toward the proposal can best be described as:", opts:["enthusiastic","dismissive","cautiously neutral","hostile"], a:2, diff:"Medium",
      why:"The author notes both ambition and cost without taking a firm side, cautiously neutral." }
  ],
  rw_info: [
    { passage:"A 2023 study tracked 1,200 students over four years. Those who studied in short, frequent sessions scored 18% higher on final exams than those who studied in long, infrequent sessions, even when total study time was identical.",
      q:"Which choice best states the main idea?", opts:["Students should study more hours","Short, frequent study sessions improve retention","Final exams are the best measure of learning","Studying in groups is beneficial"], a:1, diff:"Easy",
      why:"The study specifically compares frequency of study sessions while holding total time constant, showing frequent short sessions win." },
    { passage:"The graph shows enrollment in online courses from 2010 to 2020. Enrollment was flat until 2014, then rose steadily, reaching a peak in 2020.",
      q:"The data in the graph best support which claim?", opts:["Enrollment fell every year","Enrollment rose steadily after 2014","Enrollment was unchanged throughout","Enrollment peaked in 2010"], a:1, diff:"Easy",
      why:"The graph shows a clear upward trend starting around 2014, the best-supported claim." },
    { passage:"Researchers hypothesized that urban noise would reduce bird species diversity. To their surprise, they found the opposite: noisy neighborhoods hosted more species than quiet ones, likely because they also had more parks.",
      q:"Which choice best describes the role of the final clause?", opts:["It contradicts the hypothesis","It offers a possible explanation for the result","It introduces new data","It restates the hypothesis"], a:1, diff:"Medium",
      why:"The 'likely because...' clause offers a possible explanation for the surprising result." },
    { passage:"The author argues that standardized testing measures not learning but test-taking skill. She cites studies showing that coaching can raise scores without improving underlying knowledge.",
      q:"Which choice best states the author's central claim?", opts:["Tests should be abolished","Tests measure test-taking skill, not learning","Coaching is unfair","Studies of testing are unreliable"], a:1, diff:"Easy",
      why:"The claim is stated in the first sentence and supported by the second." },
    { passage:"The table shows average commute times in five cities. City A: 24 min. City B: 31 min. City C: 42 min. City D: 28 min. City E: 35 min.",
      q:"Which city has a commute time closest to the average of the five?", opts:["City A","City B","City C","City D"], a:1, diff:"Medium",
      why:"Average = (24+31+42+28+35)/5 = 160/5 = 32. City B (31) is closest." },
    { passage:"The study found a correlation between sleep and grades. Students sleeping 7+ hours averaged 3.4 GPA; those sleeping under 6 averaged 2.9. The authors caution that correlation is not causation.",
      q:"Why do the authors include the caution about correlation?", opts:["To undermine their own findings","To acknowledge that other factors may explain the pattern","To argue for more sleep","To criticize other researchers"], a:1, diff:"Medium",
      why:"The caution acknowledges that a third factor (e.g., study habits, health) could explain the pattern." },
    { passage:"The passage describes two theories of language acquisition: one claims it is innate, the other that it is learned through environment. The author notes both have supporting evidence.",
      q:"The author's approach to the two theories is best described as:", opts:["dismissive of both","balanced","favoring the first","favoring the second"], a:1, diff:"Easy",
      why:"The author presents supporting evidence for both, a balanced approach." },
    { passage:"A researcher found that students who took handwritten notes outperformed laptop note-takers on conceptual questions, even though laptop users recorded more words verbatim.",
      q:"Which choice best explains the finding?", opts:["Handwriting is faster","Verbatim transcription may reduce processing","Laptops are distracting","Conceptual questions are easier"], a:1, diff:"Hard",
      why:"The finding suggests that verbatim transcription reduces deeper processing, a common interpretation in the note-taking literature." }
  ],
  rw_conv: [
    { q:"Which choice completes the text so that it conforms to Standard English?\n\nThe team, along with its coach, _____ ready.", opts:["were","was","are","have been"], a:1, diff:"Easy",
      why:"The subject is 'team' (singular). 'Along with its coach' is a parenthetical phrase and does not change the verb. Use 'was'." },
    { q:"Which transition best fits?\n\nThe hypothesis was bold. _____, it was supported by three independent studies.", opts:["However","Nevertheless","Moreover","Therefore"], a:2, diff:"Easy",
      why:"The second sentence adds supporting information, 'Moreover' signals addition." },
    { q:"Which choice is grammatically correct?", opts:["Its a beautiful day.","It's a beautiful day.","Its' a beautiful day.","It is' a beautiful day."], a:1, diff:"Easy",
      why:"'It's' is the contraction of 'it is.' 'Its' is possessive." },
    { q:"Which choice completes the sentence correctly?\n\nThe professor, who had taught for thirty years, _____ the award with humility.", opts:["accept","accepts","accepted","accepting"], a:2, diff:"Easy",
      why:"The main verb must agree with 'professor' (singular) in past tense. 'Accepted' is correct." },
    { q:"Which sentence uses the semicolon correctly?", opts:["I love coffee; and tea.","I love coffee; my sister prefers tea.","I love coffee; because it wakes me up.","I love coffee; waking me up."], a:1, diff:"Medium",
      why:"A semicolon joins two independent clauses. Only B has two independent clauses on both sides." },
    { q:"Which choice fixes the comma splice?\n\nThe concert was loud, it gave me a headache.", opts:["The concert was loud, it gave me a headache.","The concert was loud; it gave me a headache.","The concert was loud it gave me a headache.","The concert was loud, giving me a headache, it did."], a:1, diff:"Medium",
      why:"Two independent clauses need a semicolon (or a period, or a comma + conjunction). A semicolon fixes the splice." },
    { q:"Which choice is a complete sentence?", opts:["Running through the park.","Because I was late.","The dog barked loudly.","After the meeting ended."], a:2, diff:"Easy",
      why:"Only C has a subject and a finite verb and expresses a complete thought." },
    { q:"Which choice correctly uses the apostrophe?", opts:["The students book.","The student's book.","The students's book.","The students' book's."], a:1, diff:"Easy",
      why:"For a singular possessive noun, add 's: 'student's book.'" }
  ]
};

/* ---- additions: grid-in (student-produced response) and extra items ---- */
BANK.math_algebra.push(
  { spr:true, ans:["9"], q:"If 4x − 9 = 27, what is the value of x?", diff:"Easy",
    why:"Add 9 to both sides: 4x = 36. Divide by 4: x = 9." },
  { spr:true, ans:["9"], q:"A gym charges a $30 sign-up fee plus $25 per month. For how many months is the total cost $255?", diff:"Medium",
    why:"Set up 30 + 25m = 255. Then 25m = 225, so m = 9." },
  { q:"Which system of equations has no solution?", opts:["y = 2x + 1 and y = 2x + 5","y = 2x + 1 and y = −2x + 1","y = x and y = 2x","y = 3x and y = 3x"], a:0, diff:"Medium",
    why:"Parallel lines have the same slope and different intercepts, so they never meet. Only the first pair does that." },
  { spr:true, ans:["5"], q:"If 3(2x − 1) = 2(x + 5) + 7, what is the value of x?", diff:"Hard",
    why:"Expand: 6x − 3 = 2x + 17. Subtract 2x and add 3: 4x = 20, so x = 5." }
);
BANK.math_adv.push(
  { spr:true, ans:["5"], q:"What is the positive solution to x² − 3x − 10 = 0?", diff:"Medium",
    why:"Factor: (x − 5)(x + 2) = 0, so x = 5 or x = −2. The positive solution is 5." },
  { spr:true, ans:["20"], q:"If f(x) = 3x² − 2x + 4, what is the value of f(−2)?", diff:"Medium",
    why:"f(−2) = 3(4) − 2(−2) + 4 = 12 + 4 + 4 = 20." },
  { q:"Which equation has the solutions x = 2 and x = −5?", opts:["x² + 3x − 10 = 0","x² − 3x − 10 = 0","x² + 7x + 10 = 0","x² − 7x + 10 = 0"], a:0, diff:"Medium",
    why:"The factors are (x − 2)(x + 5). Multiplying gives x² + 3x − 10." },
  { q:"A circle in the xy-plane has the equation (x − 3)² + (y + 1)² = 16. What is its radius?", opts:["4","8","16","√3"], a:0, diff:"Easy",
    why:"The standard form is (x − h)² + (y − k)² = r². Here r² = 16, so r = 4." },
  { spr:true, ans:["12"], q:"A right triangle has a hypotenuse of length 13 and one leg of length 5. What is the length of the other leg?", diff:"Easy",
    why:"By the Pythagorean theorem, 5² + b² = 13², so b² = 169 − 25 = 144 and b = 12." }
);
BANK.rw_craft.push(
  { passage:"Although the critic's review was largely positive, it contained one _____ remark about the film's pacing that the director could not ignore.",
    q:"Which choice completes the text with the most logical and precise word?", opts:["scathing","glowing","neutral","redundant"], a:0, diff:"Medium",
    why:"'Although' signals contrast with the positive review, and the remark was one the director could not ignore. 'Scathing' fits both clues." },
  { passage:"When the harbor town's cannery closed in 1998, the population fell by half within a decade. Today, however, converted warehouses house studios and cafes, and the census count has begun to climb again.",
    q:"Which choice best describes the overall structure of the text?", opts:["A decline followed by a recovery","A comparison of two industries","An argument against redevelopment","A history of the cannery's operations"], a:0, diff:"Medium",
    why:"The first sentence describes the decline and 'however' pivots to the recovery in the second." }
);
BANK.rw_info.push(
  { passage:"In a trial, 200 plants were grown under blue light and 200 under red light. After six weeks, the blue-light plants averaged 14 cm and the red-light plants averaged 11 cm. The researchers concluded that blue light promotes stem growth.",
    q:"Which finding, if true, would most directly weaken the researchers' conclusion?", opts:["The blue-light plants were 3 cm taller than the red-light plants when the trial began.","Red light is more common in commercial greenhouses.","Both groups received the same amount of water.","The trial lasted six weeks."], a:0, diff:"Hard",
    why:"If the blue-light plants started 3 cm taller, most of the 3 cm difference at the end is explained by the head start, not by the light." },
  { passage:"Marine biologists tagged 40 sea turtles and found that 31 of them returned to the beach where they hatched in order to nest.",
    q:"Which choice most accurately states a conclusion supported by the data?", opts:["Most of the tagged turtles nested on the beach where they hatched.","All sea turtles return to the beach where they hatched.","Sea turtles prefer cold water.","Tagging reduced the number of turtles nesting."], a:0, diff:"Easy",
    why:"31 of 40 is a clear majority of the tagged turtles. The other choices claim more than the data shows." }
);
BANK.rw_conv.push(
  { q:"Which choice completes the text so that it conforms to Standard English?\n\nThe novels that she wrote in the 1990s _____ still read in schools today.", opts:["is","are","was","has been"], a:1, diff:"Easy",
    why:"The subject is 'novels' (plural), so the verb must be plural and present tense: 'are'." },
  { q:"Which choice completes the text so that it conforms to Standard English?\n\nNeither the students nor the teacher _____ aware of the schedule change.", opts:["were","are","was","have been"], a:2, diff:"Medium",
    why:"With 'neither...nor', the verb agrees with the closer subject. 'Teacher' is singular, so 'was' is correct." },
  { q:"Which choice completes the text so that it conforms to Standard English?\n\nThe museum's newest exhibit _____ opens Friday.", opts:[", a collection of 19th-century maps,",", a collection of 19th-century maps"," a collection of 19th-century maps,","; a collection of 19th-century maps,"], a:0, diff:"Medium",
    why:"The phrase is a nonessential appositive. It needs a comma before and after it, so the sentence still reads cleanly without it." },
  { q:"Which choice completes the text so that it conforms to Standard English?\n\nShe studied for weeks, _____ she passed the exam with the highest score in her class.", opts:["so","because","although","unless"], a:0, diff:"Easy",
    why:"The second clause is a result of the first. 'So' joins cause and effect." }
);
